<?php 

class Transporter extends CI_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Transporter_model');
     $user_data = $this->session->userdata();
         if($user_data['username'] == ''){
          redirect('logout');
        }
	} 
 /*
* Listing of transporter
 */
public function index()
{
	try{
		$data['noof_page'] = 0;
		$data['transporter'] = $this->Transporter_model->get_all_transporter();
		$data['_view'] = 'transporter/index';
		$this->load->view('transporter/index',$data);
	} catch (Exception $ex) {
		throw new Exception('Transporter Controller : Error in index function - ' . $ex);
	}  
}
 /*
  * Adding a new transporter
  */
 function add()
 {  
 	try{
 		$params = array(
 			'transporter_name'=> $this->input->post('transporter_name'),
 			'company_name'=> $this->input->post('company_name'),
 			'address'=> $this->input->post('address'),
 			'contact_person_name'=> $this->input->post('contact_person_name'),
 			'contact_person_number'=> $this->input->post('contact_person_number'),
 			'status'=> 'Y',
 			'company_id'=> '1',
 			'created_at'=> date('Y-m-d H:m:s'),
 		);
 		$this->load->library('upload');
 		$this->load->library('form_validation');
 		if(isset($_POST) && count($_POST) > 0)     
 		{  
 			$id= $this->Transporter_model->add_transporter($params);
 			$this->session->set_flashdata('alert_msg','<div class="alert alert-success text-center">Succesfully added.</div>');
 			redirect('transporter/index');
 		}
 		else
 		{ 
 			$data['_view'] = 'transporter/add';
 			$this->load->view('transporter/add',$data);
 		}
 	} catch (Exception $ex) {
 		throw new Exception('Transporter Controller : Error in add function - ' . $ex);
 	}  
 }  
  /*
  * Editing a transporter
 */
  public function edit($id)
  {   
  	try{
  		$data['transporter'] = $this->Transporter_model->get_transporter($id);
  		$this->load->library('upload');
  		$this->load->library('form_validation');
  		if(isset($data['transporter']['id']))
  		{
  			$params = array(
  				'transporter_name'=> $this->input->post('transporter_name'),
  				'company_name'=> $this->input->post('company_name'),
  				'address'=> $this->input->post('address'),
  				'contact_person_name'=> $this->input->post('contact_person_name'),
  				'contact_person_number'=> $this->input->post('contact_person_number'),
  				'status'=> 'Y',
 				'company_id'=> '1',
 				'updated_at'=> date('Y-m-d H:m:s'),
  			
  			);
  			if(isset($_POST) && count($_POST) > 0)     
  			{  
  				$this->Transporter_model->update_transporter($id,$params);
  				$this->session->set_flashdata('alert_msg','<div class="alert alert-success text-center">Succesfully updated.</div>');
  				redirect('transporter/index');
  			}
  			else
  			{
  				$data['_view'] = 'transporter/edit';
  				$this->load->view('transporter/edit',$data);
  			}
  		}
  		else
  			show_error('The transporter you are trying to edit does not exist.');
  	} catch (Exception $ex) {
  		throw new Exception('Transporter Controller : Error in edit function - ' . $ex);
  	}  
  } 
/*
  * Deleting transporter
  */
function remove($id)
{
	try{
		$transporter = $this->Transporter_model->get_transporter($id);
  // check if the transporter exists before trying to delete it
		if(isset($transporter['id']))
		{
			$this->Transporter_model->delete_transporter($id);
			$this->session->set_flashdata('alert_msg','<div class="alert alert-success text-center">Succesfully Removed.</div>');
			redirect('transporter/index');
		}
		else
			show_error('The transporter you are trying to delete does not exist.');
	} catch (Exception $ex) {
		throw new Exception('Transporter Controller : Error in remove function - ' . $ex);
	}  
}
  /*
  * View more a transporter
 */
  public function view_more($id)
  {   
  	try{
  		$data['transporter'] = $this->Transporter_model->get_transporter($id);
  		if(isset($data['transporter']['id']))
  		{
  			$data['_view'] = 'transporter/view_more';
  			$this->load->view('layouts/main',$data);
  		}
  		else
  			show_error('The transporter you are trying to view more does not exist.');
  	} catch (Exception $ex) {
  		throw new Exception('Transporter Controller : Error in View more function - ' . $ex);
  	}  
  } 
 /*
* Listing of transporter
 */
public function search_by_clm()
{
	$column_name= $this->input->post('column_name');
	$value_id= $this->input->post('value_id');
	$data['noof_page'] = 0;
	$params = array();
	$data['transporter'] = $this->Transporter_model->get_all_transporter_by_cat($column_name,$value_id);
	$data['_view'] = 'transporter/index';
	$this->load->view('layouts/main',$data);
}

public function get_search_values_by_clm()
{
	$clm_name= $this->input->post('clm_name');
	$value= $this->input->post('value');
	$id= $this->input->post('id');
	$params = array(
		$clm_name=>$value,
	);
	$this->Transporter_model->update_transporter($id,$params);
	$data['noof_page'] = 0;
	$data['transporter'] = $this->Transporter_model->get_all_transporter();
	$this->load->view('transporter/index',$data);
}
}
