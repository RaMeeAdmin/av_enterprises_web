<?php
class Dashboard extends CI_Controller{
    function __construct()
    {
        parent::__construct();
       $user_data = $this->session->userdata();
         if($user_data['username'] == ''){
          redirect('logout');
        }
    }

    function index()
    {
    	 
        $data['_view'] = 'dashboard';
        $this->load->view('dashboard',$data);
    }
}
