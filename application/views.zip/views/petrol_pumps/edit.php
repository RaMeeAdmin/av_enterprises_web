<?php $this->load->view('section/header'); ?>
<?php $this->load->view('section/sidebar'); ?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Petrol Pumps Edit</h3>
            <?php echo form_open('petrol_pumps/edit/'.$petrol_pumps['id']); ?>
            <div class="box-body">
              <div class="row clearfix">
               <div class="col-md-6">
                 <label for="petrol_pumps_name" class="control-label">  <span class="text-danger"></span>Petrol pumps name</label>
                 <div class="form-group">
                  <input type="text" name="petrol_pumps_name" value="<?php echo ($this->input->post('petrol_pumps_name') ? $this->input->post('petrol_pumps_name') : $petrol_pumps['petrol_pumps_name']); ?>" class="form-control" id="petrol_pumps_name" required="required" />
                  <span class="text-danger"><?php echo form_error('petrol_pumps_name');?></span>
                </div>
              </div> 
              <div class="col-md-6">
               <label for="address" class="control-label">  <span class="text-danger"></span>Address</label>
               <div class="form-group">
                <input type="text" name="address" value="<?php echo ($this->input->post('address') ? $this->input->post('address') : $petrol_pumps['address']); ?>" class="form-control" id="address"  required="required"/>
                <span class="text-danger"><?php echo form_error('address');?></span>
              </div>
            </div> 
            <div class="col-md-6">
             <label for="contact_person_name" class="control-label">  <span class="text-danger"></span>Contact person name</label>
             <div class="form-group">
              <input type="text" name="contact_person_name" value="<?php echo ($this->input->post('contact_person_name') ? $this->input->post('contact_person_name') : $petrol_pumps['contact_person_name']); ?>" class="form-control" id="contact_person_name" required="required" />
              <span class="text-danger"><?php echo form_error('contact_person_name');?></span>
            </div>
          </div> 
          <div class="col-md-6">
           <label for="contact_person_number" class="control-label">  <span class="text-danger"></span>Contact person number</label>
           <div class="form-group">
            <input type="text" name="contact_person_number" value="<?php echo ($this->input->post('contact_person_number') ? $this->input->post('contact_person_number') : $petrol_pumps['contact_person_number']); ?>" class="form-control" id="contact_person_number" />
            <span class="text-danger"><?php echo form_error('contact_person_number');?></span>
          </div>
        </div>               
      </div>
    </div>
    <div class="box-footer">
      <button type="submit" class="btn btn-success">
        <i class="fa fa-check"></i> Save
      </button>
    </div>
    <?php echo form_close(); ?>
  </div>
</div>
</div>
</div>
</section>
</div>
<?php $this->load->view('section/footer'); ?>