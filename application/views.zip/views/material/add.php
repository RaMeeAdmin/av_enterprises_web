<?php $this->load->view('section/header'); ?>
<?php $this->load->view('section/sidebar'); ?>
<div class="content-wrapper">
  <section class="content">
<div class="row">
    <div class="col-md-12">
      <div class="box box-primary">
      <div class="box-header">
            <h3 class="box-title">Add New Material</h3>
            </div>
            <div class="box-body">
            <?php echo form_open('material/add'); ?>
            <!--  <div class="col-md-6">
               <label for="date" class="control-label"> <span class="text-danger"></span>Date</label>
                <div class="form-group">
                  <input type="date" name="date" value="<?php echo $this->input->post('date'); ?>" class="form-control my-colorpicker1 " data-date-format='YYYY-MM-DD' id="date" required="required" />
                   <span class="text-danger"><?php echo form_error('date');?></span>
               </div>
             </div> -->
             <div class="col-md-6">
               <label for="name" class="control-label"> <span class="text-danger"></span>Name</label>
                <div class="form-group">
                  <input type="text" name="name" value="<?php echo $this->input->post('name'); ?>" class="form-control " id="name" required="required" />
                   <span class="text-danger"><?php echo form_error('name');?></span>
               </div>
             </div>
             <!-- <div class="col-md-6">
               <label for="quantity" class="control-label"> <span class="text-danger"></span>Quantity</label>
                <div class="form-group">
                  <input type="text" name="quantity" value="<?php echo $this->input->post('quantity'); ?>" class="form-control " id="quantity" />
                   <span class="text-danger"><?php echo form_error('quantity');?></span>
               </div>
             </div> -->
            
             <div class="col-md-12">
               <label for=" " class="control-label"> </label>
                <div class="form-group">
                   <button type="submit" class="btn btn-success">  
                   <i class="fa fa-check"></i> Save 
                        </button> 
               </div>
             </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
</section>
</div>
<?php $this->load->view('section/footer'); ?>
