<?php $this->load->view('section/header'); ?>
<?php $this->load->view('section/sidebar'); ?>
<div class="content-wrapper">
  <section class="content">
<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Suppliers Edit</h3>
            <?php echo form_open('suppliers/edit/'.$suppliers['id']); ?>
            <div class="box-body">
              <div class="row clearfix">
        
                        <div class="col-md-6">
               <label for="company_name" class="control-label">  <span class="text-danger"></span>Company name</label>
                <div class="form-group">
                  <input type="text" name="company_name" value="<?php echo ($this->input->post('company_name') ? $this->input->post('company_name') : $suppliers['company_name']); ?>" class="form-control" id="company_name" required="required" />
                    <span class="text-danger"><?php echo form_error('company_name');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="address" class="control-label">  <span class="text-danger"></span>Address</label>
                <div class="form-group">
                  <input type="text" name="address" value="<?php echo ($this->input->post('address') ? $this->input->post('address') : $suppliers['address']); ?>" class="form-control" id="address" required="required"/>
                    <span class="text-danger"><?php echo form_error('address');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="state" class="control-label">  <span class="text-danger"></span>State</label>
                <div class="form-group">
                 <!--  <input type="text" name="state" value="<?php echo ($this->input->post('state') ? $this->input->post('state') : $suppliers['state']); ?>" class="form-control" id="state" /> -->
                <select class="form-control" name="state" id="state" required="required">
                    <?php foreach ($state as $key ) {?>
                       <!-- <option value="<?php //echo $key['state_id'] ?>"><?php echo $key['name'] ?></option> -->
                       <option value="<?php echo $suppliers['state']; ?>"<?php if($key['state_id']==$suppliers['state']) echo 'selected="selected"'; ?>><?php echo $key['name']; ?></option>
                  <?php  } ?>
                    </select>
                    <span class="text-danger"><?php echo form_error('state');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="phone" class="control-label">  <span class="text-danger"></span>Phone</label>
                <div class="form-group">
                  <input type="text" name="phone" value="<?php echo ($this->input->post('phone') ? $this->input->post('phone') : $suppliers['phone']); ?>" class="form-control" id="phone" />
                    <span class="text-danger"><?php echo form_error('phone');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="contact_person_name" class="control-label">  <span class="text-danger"></span>Contact person name</label>
                <div class="form-group">
                  <input type="text" name="contact_person_name" value="<?php echo ($this->input->post('contact_person_name') ? $this->input->post('contact_person_name') : $suppliers['contact_person_name']); ?>" class="form-control" id="contact_person_name" />
                    <span class="text-danger"><?php echo form_error('contact_person_name');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="contact_person_number" class="control-label">  <span class="text-danger"></span>Contact person number</label>
                <div class="form-group">
                  <input type="text" name="contact_person_number" value="<?php echo ($this->input->post('contact_person_number') ? $this->input->post('contact_person_number') : $suppliers['contact_person_number']); ?>" class="form-control" id="contact_person_number" />
                    <span class="text-danger"><?php echo form_error('contact_person_number');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="email" class="control-label">  <span class="text-danger"></span>Email</label>
                <div class="form-group">
                  <input type="text" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $suppliers['email']); ?>" class="form-control" id="email" />
                    <span class="text-danger"><?php echo form_error('email');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="gstn_uin" class="control-label">  <span class="text-danger"></span>Gstn uin</label>
                <div class="form-group">
                  <input type="text" name="gstn_uin" value="<?php echo ($this->input->post('gstn_uin') ? $this->input->post('gstn_uin') : $suppliers['gstn_uin']); ?>" class="form-control" id="gstn_uin" />
                    <span class="text-danger"><?php echo form_error('gstn_uin');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="opening_balance" class="control-label">  <span class="text-danger"></span>Opening balance</label>
                <div class="form-group">
                  <input type="text" name="opening_balance" value="<?php echo ($this->input->post('opening_balance') ? $this->input->post('opening_balance') : $suppliers['opening_balance']); ?>" class="form-control" id="opening_balance" />
                    <span class="text-danger"><?php echo form_error('opening_balance');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="cr_dr" class="control-label">  <span class="text-danger"></span>Cr dr</label>
                <div class="form-group">
                  <input type="text" name="cr_dr" value="<?php echo ($this->input->post('cr_dr') ? $this->input->post('cr_dr') : $suppliers['cr_dr']); ?>" class="form-control" id="cr_dr" />
                    <span class="text-danger"><?php echo form_error('cr_dr');?></span>
               </div>
             </div> 
                     <!--    <div class="col-md-6">
               <label for="status" class="control-label">  <span class="text-danger"></span>Status</label>
                <div class="form-group">
               <select class="form-control" name="state" id="state" required="required">
                    <?php //foreach ($state as $key ) {?>
                       <option value="<?php// echo $suppliers['state']; ?>"<?php //if($key['state_id']==$suppliers['state']) echo 'selected="selected"'; ?>><?php// echo $key['name']; ?></option>
                  <?php // } ?>
                    </select>
                    <span class="text-danger"><?php //echo form_error('status');?></span>
               </div>
             </div>  -->
                   <!--      <div class="col-md-6">
               <label for="company_id" class="control-label">  <span class="text-danger"></span>Company id</label>
                <div class="form-group">
                  <input type="text" name="company_id" value="<?php echo ($this->input->post('company_id') ? $this->input->post('company_id') : $suppliers['company_id']); ?>" class="form-control" id="company_id" />
                    <span class="text-danger"><?php echo form_error('company_id');?></span>
               </div>
             </div> --> 
                   <!--      <div class="col-md-6">
               <label for="created_at" class="control-label">  <span class="text-danger"></span>Created at</label>
                <div class="form-group">
                  <input type="text" name="created_at" value="<?php echo ($this->input->post('created_at') ? $this->input->post('created_at') : $suppliers['created_at']); ?>" class="form-control" id="created_at" />
                    <span class="text-danger"><?php echo form_error('created_at');?></span>
               </div>
             </div>  -->
             <!-- <div class="col-md-6">
               <label for="updated_at" class="control-label">  <span class="text-danger"></span>Updated at</label>
                <div class="form-group">
                  <input type="text" name="updated_at" value="<?php echo ($this->input->post('updated_at') ? $this->input->post('updated_at') : $suppliers['updated_at']); ?>" class="has-datepicker form-control" data-date-format='YYYY-MM-DD' id="updated_at" />
                   <span class="text-danger"><?php echo form_error('updated_at');?></span>
               </div>
             </div> -->
        </div>
      </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
</div>
</section>
</div>
<?php $this->load->view('section/footer'); ?>