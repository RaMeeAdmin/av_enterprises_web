<?php $this->load->view('section/header'); ?>
<?php $this->load->view('section/sidebar'); ?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Transporter Edit</h3>
            <?php echo form_open('transporter/edit/'.$transporter['id']); ?>
            <div class="box-body">
              <div class="row clearfix">
                <div class="col-md-6">
                 <label for="transporter_name" class="control-label">  <span class="text-danger"></span>Transporter name</label>
                 <div class="form-group">
                  <input type="text" name="transporter_name" value="<?php echo ($this->input->post('transporter_name') ? $this->input->post('transporter_name') : $transporter['transporter_name']); ?>" class="form-control" id="transporter_name" />
                  <span class="text-danger"><?php echo form_error('transporter_name');?></span>
                </div>
              </div> 
              <div class="col-md-6">
               <label for="company_name" class="control-label">  <span class="text-danger"></span>Company name</label>
               <div class="form-group">
                <input type="text" name="company_name" value="<?php echo ($this->input->post('company_name') ? $this->input->post('company_name') : $transporter['company_name']); ?>" class="form-control" id="company_name" required="required"/>
                <span class="text-danger"><?php echo form_error('company_name');?></span>
              </div>
            </div> 
            <div class="col-md-6">
             <label for="address" class="control-label">  <span class="text-danger"></span>Address</label>
             <div class="form-group">
              <input type="text" name="address" value="<?php echo ($this->input->post('address') ? $this->input->post('address') : $transporter['address']); ?>" class="form-control" id="address" required="required" />
              <span class="text-danger"><?php echo form_error('address');?></span>
            </div>
          </div> 
          <div class="col-md-6">
           <label for="contact_person_name" class="control-label">  <span class="text-danger"></span>Contact person name</label>
           <div class="form-group">
            <input type="text" name="contact_person_name" value="<?php echo ($this->input->post('contact_person_name') ? $this->input->post('contact_person_name') : $transporter['contact_person_name']); ?>" class="form-control" id="contact_person_name" required="required" />
            <span class="text-danger"><?php echo form_error('contact_person_name');?></span>
          </div>
        </div> 
        <div class="col-md-6">
         <label for="contact_person_number" class="control-label">  <span class="text-danger"></span>Contact person number</label>
         <div class="form-group">
          <input type="text" name="contact_person_number" value="<?php echo ($this->input->post('contact_person_number') ? $this->input->post('contact_person_number') : $transporter['contact_person_number']); ?>" class="form-control" id="contact_person_number" required="required" />
          <span class="text-danger"><?php echo form_error('contact_person_number');?></span>
        </div>
      </div> 

    </div>
  </div>
  <div class="box-footer">
    <button type="submit" class="btn btn-success">
      <i class="fa fa-check"></i> Save
    </button>
  </div>
  <?php echo form_close(); ?>
</div>
</div>
</div>
</div>
</section>
</div>
<?php $this->load->view('section/footer'); ?>