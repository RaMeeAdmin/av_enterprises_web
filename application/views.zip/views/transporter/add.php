<?php $this->load->view('section/header'); ?>
<?php $this->load->view('section/sidebar'); ?>
<div class="content-wrapper">
  <section class="content">
<div class="row">
    <div class="col-md-12">
      <div class="box box-primary">
      <div class="box-header">
            <h3 class="box-title">Add New Transporter</h3>
            </div>
            <div class="box-body">
            <?php echo form_open('transporter/add'); ?>
            <div class="col-md-6">
               <label for="transporter_name" class="control-label"> <span class="text-danger"></span>Transporter name</label>
                <div class="form-group">
                  <input type="text" name="transporter_name" value="<?php echo $this->input->post('transporter_name'); ?>" class="form-control " id="transporter_name" required="required"/>
                   <span class="text-danger"><?php echo form_error('transporter_name');?></span>
               </div>
             </div>
             <div class="col-md-6">
               <label for="company_name" class="control-label"> <span class="text-danger"></span>Company name</label>
                <div class="form-group">
                  <input type="text" name="company_name" value="<?php echo $this->input->post('company_name'); ?>" class="form-control " id="company_name" required="required" />
                   <span class="text-danger"><?php echo form_error('company_name');?></span>
               </div>
             </div>
             <div class="col-md-6">
               <label for="address" class="control-label"> <span class="text-danger"></span>Address</label>
                <div class="form-group">
                  <input type="text" name="address" value="<?php echo $this->input->post('address'); ?>" class="form-control " id="address" required="required" />
                   <span class="text-danger"><?php echo form_error('address');?></span>
               </div>
             </div>
             <div class="col-md-6">
               <label for="contact_person_name" class="control-label"> <span class="text-danger"></span>Contact person name</label>
                <div class="form-group">
                  <input type="text" name="contact_person_name" value="<?php echo $this->input->post('contact_person_name'); ?>" class="form-control " id="contact_person_name" />
                   <span class="text-danger"><?php echo form_error('contact_person_name');?></span>
               </div>
             </div>
             <div class="col-md-6">
               <label for="contact_person_number" class="control-label"> <span class="text-danger"></span>Contact person number</label>
                <div class="form-group">
                  <input type="text" name="contact_person_number" value="<?php echo $this->input->post('contact_person_number'); ?>" class="form-control " id="contact_person_number" />
                   <span class="text-danger"><?php echo form_error('contact_person_number');?></span>
               </div>
             </div>
            <div class="col-md-12">
               <label for=" " class="control-label"> </label>
                <div class="form-group">
                   <button type="submit" class="btn btn-success">  
                   <i class="fa fa-check"></i> Save 
                        </button> 
               </div>
             </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
</section>
</div>
<?php $this->load->view('section/footer'); ?>