<?php $this->load->view('section/header'); ?>
<?php $this->load->view('section/sidebar'); ?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Customer Edit</h3>
            <?php echo form_open('customer/edit/'.$customer['id']); ?>
            <div class="box-body">
              <div class="row clearfix">
                <div class="col-md-6">
                 <label for="name" class="control-label">  <span class="text-danger"></span>Name</label>
                 <div class="form-group">
                  <input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $customer['name']); ?>" class="form-control" id="name" required="required" />
                  <span class="text-danger"><?php echo form_error('name');?></span>
                </div>
              </div> 
              <div class="col-md-6">
               <label for="phone" class="control-label">  <span class="text-danger"></span>Phone</label>
               <div class="form-group">
                <input type="text" name="phone" value="<?php echo ($this->input->post('phone') ? $this->input->post('phone') : $customer['phone']); ?>" class="form-control" id="phone" required="required"/>
                <span class="text-danger"><?php echo form_error('phone');?></span>
              </div>
            </div> 
            <div class="col-md-6">
             <label for="email" class="control-label">  <span class="text-danger"></span>Email</label>
             <div class="form-group">
              <input type="text" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $customer['email']); ?>" class="form-control" id="email" required="required"/>
              <span class="text-danger"><?php echo form_error('email');?></span>
            </div>
          </div> 
          <div class="col-md-6">
           <label for="address" class="control-label">  <span class="text-danger"></span>Address</label>
           <div class="form-group">
            <input type="text" name="address" value="<?php echo ($this->input->post('address') ? $this->input->post('address') : $customer['address']); ?>" class="form-control" id="address" required="required"/>
            <span class="text-danger"><?php echo form_error('address');?></span>
          </div>
        </div> 
        <div class="col-md-6">
         <label for="state" class="control-label">  <span class="text-danger"></span>State</label>
         <div class="form-group">
          <select class="form-control" name="state" id="state" required="required">
                    <?php foreach ($state as $key ) {?>
                     <option value="<?php echo $customer['state']; ?>"<?php if($key['state_id']==$customer['state']) echo 'selected="selected"'; ?>><?php echo $key['name']; ?></option>
                  <?php  } ?>
                    </select>
          <span class="text-danger"><?php echo form_error('state');?></span>
        </div>
      </div> 
      <div class="col-md-6">
       <label for="contact_person_name" class="control-label">  <span class="text-danger"></span>Contact person name</label>
       <div class="form-group">
        <input type="text"  name="contact_person_name" value="<?php echo ($this->input->post('contact_person_name') ? $this->input->post('contact_person_name') : $customer['contact_person_name']); ?>" class="form-control" id="contact_person_name" required="required" />
        <span class="text-danger"><?php echo form_error('contact_person_name');?></span>
      </div>
    </div> 
    <div class="col-md-6">
     <label for="contact_person_contact_number" class="control-label">  <span class="text-danger"></span>Contact person contact number</label>
     <div class="form-group">
      <input type="text" name="contact_person_contact_number" value="<?php echo ($this->input->post('contact_person_contact_number') ? $this->input->post('contact_person_contact_number') : $customer['contact_person_contact_number']); ?>" class="form-control" id="contact_person_contact_number" />
      <span class="text-danger"><?php echo form_error('contact_person_contact_number');?></span>
    </div>
  </div> 
  <div class="col-md-6">
   <label for="gstn_uin" class="control-label">  <span class="text-danger"></span>Gstn uin</label>
   <div class="form-group">
    <input type="text" name="gstn_uin" value="<?php echo ($this->input->post('gstn_uin') ? $this->input->post('gstn_uin') : $customer['gstn_uin']); ?>" class="form-control" id="gstn_uin" />
    <span class="text-danger"><?php echo form_error('gstn_uin');?></span>
  </div>
</div> 
<div class="col-md-6">
 <label for="credit_days" class="control-label">  <span class="text-danger"></span>Credit days</label>
 <div class="form-group">
  <input type="text" name="credit_days" value="<?php echo ($this->input->post('credit_days') ? $this->input->post('credit_days') : $customer['credit_days']); ?>" class="form-control" id="credit_days" />
  <span class="text-danger"><?php echo form_error('credit_days');?></span>
</div>
</div> 
                     <!--    <div class="col-md-6">
               <label for="status" class="control-label">  <span class="text-danger"></span>Status</label>
                <div class="form-group">
                  <input type="text" name="status" value="<?php echo ($this->input->post('status') ? $this->input->post('status') : $customer['status']); ?>" class="form-control" id="status" />
                    <span class="text-danger"><?php echo form_error('status');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="company_id" class="control-label">  <span class="text-danger"></span>Company id</label>
                <div class="form-group">
                  <input type="text" name="company_id" value="<?php echo ($this->input->post('company_id') ? $this->input->post('company_id') : $customer['company_id']); ?>" class="form-control" id="company_id" />
                    <span class="text-danger"><?php echo form_error('company_id');?></span>
               </div>
             </div> 
                        <div class="col-md-6">
               <label for="created_at" class="control-label">  <span class="text-danger"></span>Created at</label>
                <div class="form-group">
                  <input type="text" name="created_at" value="<?php echo ($this->input->post('created_at') ? $this->input->post('created_at') : $customer['created_at']); ?>" class="form-control" id="created_at" />
                    <span class="text-danger"><?php echo form_error('created_at');?></span>
               </div>
             </div> 
             <div class="col-md-6">
               <label for="updated_at" class="control-label">  <span class="text-danger"></span>Updated at</label>
                <div class="form-group">
                  <input type="text" name="updated_at" value="<?php echo ($this->input->post('updated_at') ? $this->input->post('updated_at') : $customer['updated_at']); ?>" class="has-datepicker form-control" data-date-format='YYYY-MM-DD' id="updated_at" />
                   <span class="text-danger"><?php echo form_error('updated_at');?></span>
               </div>
             </div> -->
           </div>
         </div>
         <div class="box-footer">
          <button type="submit" class="btn btn-success">
            <i class="fa fa-check"></i> Save
          </button>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
</section>
</div>
<?php $this->load->view('section/footer'); ?>